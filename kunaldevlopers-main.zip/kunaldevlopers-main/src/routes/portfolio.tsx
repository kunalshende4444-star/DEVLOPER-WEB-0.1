import { createFileRoute } from '@tanstack/react-router';
import { pageHead } from '@/lib/seo';
import { PageIntro } from '@/components/studio/section-heading';
import { PortfolioGrid } from '@/components/studio/portfolio';
export const Route = createFileRoute('/portfolio')({
  head: () => pageHead('Portfolio Concepts | Kunal SMK Development', 'Explore original UI concepts, not completed client projects. Every example is a starting point for a conversation.', '/portfolio'),
  component: Page,
});
function Page() { return <><PageIntro label="Portfolio concepts" title="A LOOK AT WHAT’S POSSIBLE." description="Explore original UI concepts, not completed client projects. Every example is a starting point for a conversation."/><div className="shell page-body"><PortfolioGrid/></div></>; }
