import { createFileRoute } from '@tanstack/react-router';
import { pageHead } from '@/lib/seo';
import { PageIntro } from '@/components/studio/section-heading';
import { ServicesGrid, Discovery } from '@/components/studio/services';
export const Route = createFileRoute('/services')({
  head: () => pageHead('Development Services | Kunal SMK Development', 'Websites, Android applications, custom systems and integrations. Discuss what you need, then agree on the right scope.', '/services'),
  component: Page,
});
function Page() { return <><PageIntro label="Development services" title="YOUR VISION. BUILT RIGHT." description="Websites, Android applications, custom systems and integrations. Discuss what you need, then agree on the right scope."/><div className="shell page-body"><ServicesGrid/><Discovery/></div></>; }
