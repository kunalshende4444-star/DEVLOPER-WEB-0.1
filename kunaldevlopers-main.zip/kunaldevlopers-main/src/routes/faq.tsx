import { createFileRoute } from '@tanstack/react-router';
import { pageHead } from '@/lib/seo';
import { PageIntro } from '@/components/studio/section-heading';
import { FAQList } from '@/components/studio/faq';
export const Route = createFileRoute('/faq')({
  head: () => pageHead('Frequently Asked Questions | Kunal SMK Development', 'A few things to know before discussing your next website, application or custom development project.', '/faq'),
  component: Page,
});
function Page() { return <><PageIntro label="Frequently asked questions" title="GOOD QUESTIONS. CLEAR ANSWERS." description="A few things to know before discussing your next website, application or custom development project."/><div className="shell page-body"><FAQList/></div></>; }
