import { createFileRoute } from '@tanstack/react-router';
import { pageHead } from '@/lib/seo';
import { PageIntro } from '@/components/studio/section-heading';
import { ProcessSteps, Principles } from '@/components/studio/process-pricing';
import { SectionHeading } from '@/components/studio/section-heading';
export const Route = createFileRoute('/process')({
  head: () => pageHead('Our Process | Kunal SMK Development', 'A straightforward development process built around clear requirements, an agreed scope and practical communication.', '/process'),
  component: Page,
});
function Page() { return <><PageIntro label="Our process" title="FROM IDEA TO DELIVERY" description="A straightforward development process built around clear requirements, an agreed scope and practical communication."/><div className="shell page-body"><ProcessSteps/><div className="section"><SectionHeading label="Working together" title="WHY KUNAL SMK DEVELOPMENT"/><Principles/></div></div></>; }
