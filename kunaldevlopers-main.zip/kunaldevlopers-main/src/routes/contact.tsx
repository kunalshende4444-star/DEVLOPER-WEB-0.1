import { createFileRoute } from '@tanstack/react-router';
import { pageHead } from '@/lib/seo';
import { PageIntro } from '@/components/studio/section-heading';
import { ContactContent } from '@/components/studio/contact';
export const Route = createFileRoute('/contact')({
  head: () => pageHead('Project Inquiries | Kunal SMK Development', 'Turn your idea into a clear project discussion. Share what you need and continue the conversation on WhatsApp.', '/contact'),
  component: Page,
});
function Page() { return <><PageIntro label="Project inquiries" title="LET’S DISCUSS YOUR NEXT PROJECT" description="Turn your idea into a clear project discussion. Share what you need and continue the conversation on WhatsApp."/><div className="shell page-body"><ContactContent/></div></>; }
