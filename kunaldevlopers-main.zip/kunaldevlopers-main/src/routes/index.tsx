import { createFileRoute, Link } from '@tanstack/react-router';
import { ArrowDown, ArrowUpRight, Check, Globe2, Smartphone, LayoutDashboard, Braces } from 'lucide-react';
import { Button } from '@/components/ui/button';
import heroImage from '@/assets/smk-hero.jpg';
import { pageHead } from '@/lib/seo';
import { WhatsAppLink } from '@/components/studio/whatsapp-link';
import { SectionHeading } from '@/components/studio/section-heading';
import { ServicesGrid, Discovery } from '@/components/studio/services';
import { PortfolioGrid } from '@/components/studio/portfolio';
import { ProcessSteps, PricingGrid, Principles, ProjectCTA } from '@/components/studio/process-pricing';
import { FAQList } from '@/components/studio/faq';
import { ContactContent } from '@/components/studio/contact';

export const Route = createFileRoute('/')({
  head: () => pageHead('Kunal SMK Development | Websites, Apps & Custom Software', 'Explore website development, Android apps, admin panels, tournament platforms and custom digital solutions by Kunal SMK Development.', '/'),
  component: Index,
});
function Index() {
  return <>
    <section className="hero"><picture className="hero-picture"><img className="hero-art" src={heroImage} alt="Kunal SMK Development logo: a glowing K with a code symbol and the text SMK Development" width={1000} height={1000} fetchPriority="high"/></picture><div className="shell hero-content"><div className="eyebrow">KUNAL SMK DEVELOPMENT · INDEPENDENT DEVELOPER STUDIO</div><h1>YOUR IDEA.<br/>OUR CODE.<br/><span className="accent-text">YOUR NEXT<br/>BIG MOVE.</span></h1><p className="hero-description">Websites, Android apps & custom digital solutions.<br/>Built around your business. Not the other way around.</p><div className="hero-actions"><WhatsAppLink>Discuss Your Project</WhatsAppLink><Button variant="outline" asChild className="studio-button"><a href="#home-services">Explore Services<ArrowDown/></a></Button></div><p className="hero-note"><Check aria-hidden="true"/>Clear communication. Custom solutions. Transparent discussions.</p></div><div className="hero-caption"><span>&lt;/&gt;</span> IDEAS INTO PRACTICAL DIGITAL PRODUCTS</div></section>
    <div className="capability-band"><div className="shell capability-inner">{[{ icon: Globe2, text: 'Website Development' },{ icon: Smartphone, text: 'Android Applications' },{ icon: LayoutDashboard, text: 'Admin Panels & Systems' },{ icon: Braces, text: 'Custom Digital Solutions' }].map(item => <div key={item.text}><item.icon aria-hidden="true"/>{item.text}</div>)}</div></div>
    <section className="section shell" id="home-services"><SectionHeading label="What we can build" title="YOUR VISION. BUILT RIGHT." description="From your first website to a custom platform, let's build something that fits the way you work."/><ServicesGrid compact/><Discovery/></section>
    <section className="section section-alternate"><div className="shell"><SectionHeading label="Selected concepts" title="A LOOK AT WHAT'S POSSIBLE." action={<Link to="/portfolio" className="section-link">Explore Portfolio<ArrowUpRight size={15}/></Link>}/><PortfolioGrid preview/><p className="small-note">Original UI demonstrations, not completed client projects. Shown to explore possible design directions.</p></div></section>
    <section className="section shell"><SectionHeading label="A clear path forward" title="FROM IDEA TO DELIVERY" description="No guesswork. Just a considered process, an agreed scope and clear conversations along the way."/><ProcessSteps/></section>
    <section className="section section-alternate"><div className="shell"><SectionHeading label="Project starting points" title="THE RIGHT SCOPE. A CLEAR QUOTE." description="Every project is different. Start with what you need, and we'll discuss a quote around it."/><PricingGrid/></div></section>
    <section className="section shell"><SectionHeading label="Our working principles" title="GOOD CODE. BETTER COMMUNICATION." description="Working with KUNAL SMK DEVELOPMENT starts with understanding your needs. These principles guide the discussion."/><Principles/></section>
    <ProjectCTA/>
    <section className="section shell"><SectionHeading label="Before we get started" title="A FEW GOOD QUESTIONS." action={<Link to="/faq" className="section-link">All Questions<ArrowUpRight size={15}/></Link>}/><FAQList preview/></section>
    <section className="section section-alternate"><div className="shell"><SectionHeading label="Let's talk" title="LET'S DISCUSS YOUR NEXT PROJECT"/><ContactContent/></div></section>
  </>;
}
