import { createFileRoute } from '@tanstack/react-router';
import { pageHead } from '@/lib/seo';
import { PageIntro } from '@/components/studio/section-heading';
import { PricingGrid } from '@/components/studio/process-pricing';
export const Route = createFileRoute('/pricing')({
  head: () => pageHead('Project Quotations | Kunal SMK Development', 'No one-size-fits-all pricing. Start with your requirements and discuss a transparent project quotation.', '/pricing'),
  component: Page,
});
function Page() { return <><PageIntro label="Project quotations" title="FIND THE RIGHT STARTING POINT" description="No one-size-fits-all pricing. Start with your requirements and discuss a transparent project quotation."/><div className="shell page-body"><PricingGrid/></div></>; }
