import { useState, type FormEvent } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { ArrowUpRight, Loader2, Wand2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { generateBrief, briefInputSchema } from '@/lib/brief.functions';
import { whatsappUrl } from '@/lib/whatsapp';

export function BriefAssistant() {
  const run = useServerFn(generateBrief);
  const [idea, setIdea] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [brief, setBrief] = useState('');
  async function submit(e: FormEvent) {
    e.preventDefault(); setError('');
    const parsed = briefInputSchema.safeParse({ idea });
    if (!parsed.success) { setError(parsed.error.issues[0].message); return; }
    setBusy(true); setBrief('');
    try { const r = await run({ data: parsed.data }); if (r.ok) setBrief(r.brief); else setError(r.error); }
    catch { setError('We could not generate a brief. Please try again or continue on WhatsApp.'); }
    finally { setBusy(false); }
  }
  const share = brief ? whatsappUrl(`Hi Kunal SMK, here is my project brief:\n\n${brief}`.slice(0, 4900)) : '';
  return <div className="inquiry-form brief-assistant">
    <div className="eyebrow">AI project brief</div>
    <h3>Not sure how to explain your idea?</h3>
    <p className="form-privacy">Describe it in your own words and get a draft brief with suggested next steps. It is AI-generated guidance only — scope and quotation are agreed with Kunal SMK. Do not include sensitive information.</p>
    <form onSubmit={submit} noValidate>
      <div className="form-field full"><label htmlFor="brief-idea">Your project idea</label>
        <textarea id="brief-idea" value={idea} onChange={e => setIdea(e.target.value)} maxLength={2000} placeholder="For example: a website for my gaming café where players can book slots and see tournaments…" aria-invalid={!!error} aria-describedby={error ? 'brief-error' : undefined}/></div>
      <Button type="submit" disabled={busy} className="studio-button form-submit">{busy ? <><Loader2 className="animate-spin"/>Writing Your Brief</> : <>Generate Project Brief<Wand2/></>}</Button>
    </form>
    {error && <p id="brief-error" className="field-error" role="alert">{error}</p>}
    {brief && <div className="form-next" role="status"><pre className="brief-output">{brief}</pre><Button asChild><a href={share} target="_blank" rel="noopener noreferrer">Share Brief on WhatsApp<ArrowUpRight/></a></Button></div>}
  </div>;
}
