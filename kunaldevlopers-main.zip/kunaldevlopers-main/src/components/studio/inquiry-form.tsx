import { useState, type FormEvent } from 'react';
import { Link } from '@tanstack/react-router';
import { useServerFn } from '@tanstack/react-start';
import { ArrowUpRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { projectTypes } from '@/lib/studio-config';
import { inquirySchema, inquiryMessage, whatsappUrl } from '@/lib/whatsapp';
import { saveInquiry } from '@/lib/inquiries.functions';
export function InquiryForm() {
  const [errors, setErrors] = useState<Record<string,string>>({});
  const [busy, setBusy] = useState(false);
  const [readyUrl, setReadyUrl] = useState('');
  const [failure, setFailure] = useState('');
  const save = useServerFn(saveInquiry);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setFailure(''); setReadyUrl('');
    const values = Object.fromEntries(new FormData(event.currentTarget));
    const result = inquirySchema.safeParse(values);
    if (!result.success) { const issues: Record<string,string> = {}; for (const issue of result.error.issues) issues[String(issue.path[0])] = issue.message; setErrors(issues); return; }
    setErrors({}); setBusy(true);
    // Open during the click event to avoid popup blockers; no message is sent automatically.
    const popup = window.open('about:blank', '_blank');
    if (popup) popup.opener = null;
    try {
      const response = await save({ data: result.data });
      if (!response.ok) throw new Error('Inquiry could not be saved');
      const url = whatsappUrl(inquiryMessage(result.data));
      setReadyUrl(url);
      if (popup) popup.location.href = url;
    } catch { popup?.close(); setFailure('We could not save your inquiry. Please try again, or use the WhatsApp contact button to discuss your project directly.'); }
    finally { setBusy(false); }
  }
  const error = (name: string) => errors[name] ? <p id={`${name}-error`} className="field-error" role="alert">{errors[name]}</p> : null;
  const attrs = (name: string) => ({ 'aria-invalid': !!errors[name], 'aria-describedby': errors[name] ? `${name}-error` : undefined });
  return <form className="inquiry-form" onSubmit={submit} noValidate><div className="form-grid"><div className="form-field"><label htmlFor="inquiry-name">Your name *</label><input id="inquiry-name" name="name" autoComplete="name" placeholder="What should we call you?" maxLength={100} required {...attrs('name')}/>{error('name')}</div><div className="form-field"><label htmlFor="project-type">Project type *</label><select id="project-type" name="projectType" defaultValue="" required {...attrs('projectType')}><option value="" disabled>Select a project type</option>{projectTypes.map(type => <option key={type}>{type}</option>)}</select>{error('projectType')}</div><div className="form-field full"><label htmlFor="description">Tell us about your project *</label><textarea id="description" name="description" placeholder="Your idea, who it's for, and what you'd like it to do…" maxLength={1500} required {...attrs('description')}/>{error('description')}</div><div className="form-field full"><label htmlFor="features">Required features <span>(optional)</span></label><textarea id="features" name="features" placeholder="For example: product catalog, user login, admin panel…" maxLength={1000} {...attrs('features')}/>{error('features')}</div><div className="form-field"><label htmlFor="budget">Approximate budget <span>(optional)</span></label><input id="budget" name="budget" maxLength={100} placeholder="Your range, or let's discuss"/></div><div className="form-field"><label htmlFor="desired-date">Preferred completion date <span>(optional)</span></label><input type="date" id="desired-date" name="desiredDate" {...attrs('desiredDate')}/>{error('desiredDate')}</div><div className="form-field full"><label htmlFor="contact-method">Preferred contact method</label><select id="contact-method" name="contactMethod" defaultValue="WhatsApp"><option>WhatsApp</option></select></div></div><p className="form-privacy">Submitting saves a copy of these details for project review, then opens WhatsApp. You can edit the message and must press Send there. Do not include sensitive information. <Link to="/privacy">Privacy Policy</Link></p><Button type="submit" disabled={busy} className="studio-button form-submit">{busy ? <><Loader2 className="animate-spin"/>Preparing Your Inquiry</> : <>Continue on WhatsApp<ArrowUpRight/></>}</Button>{failure && <p className="field-error" role="alert">{failure}</p>}{readyUrl && <div className="form-next" role="status"><p>Your inquiry copy has been saved. Press Send in WhatsApp to deliver your message. If WhatsApp did not open, continue below.</p><Button asChild variant="outline"><a href={readyUrl} target="_blank" rel="noopener noreferrer">Open WhatsApp<ArrowUpRight/></a></Button></div>}</form>;
}
