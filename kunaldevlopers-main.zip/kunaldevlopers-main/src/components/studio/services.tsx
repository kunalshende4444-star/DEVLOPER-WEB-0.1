import { useState } from 'react';
import { Globe2, Smartphone, LayoutDashboard, Trophy, ShoppingBag, Braces, Workflow, Wrench } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { services, projectTypes } from '@/lib/studio-config';
import { WhatsAppLink } from './whatsapp-link';
const icons = { website: Globe2, android: Smartphone, admin: LayoutDashboard, tournament: Trophy, store: ShoppingBag, integration: Braces, custom: Workflow, repair: Wrench };
export function ServicesGrid({ compact = false }: { compact?: boolean }) {
  return <div className="service-grid">{services.filter(s => s.enabled).map(service => { const Icon = icons[service.icon as keyof typeof icons]; return <article className="service-card" key={service.id}><div className="service-icon"><Icon aria-hidden="true"/></div><h3>{service.title}</h3><p>{service.description}</p><ul>{service.capabilities.map(c => <li key={c}>{c}</li>)}</ul>{!compact && service.note && <p className="service-note">{service.note}</p>}<WhatsAppLink message={service.message} variant="ghost" className="service-action">{service.cta}</WhatsAppLink></article>; })}</div>;
}
export function Discovery() {
  const [category, setCategory] = useState<string>('Website');
  return <div className="discovery"><div><div className="eyebrow">Let's figure it out</div><h3>NOT SURE WHAT YOU NEED?</h3><p>You don't need to know the technical terms. Tell us what you're trying to achieve, and let's find a practical starting point.</p></div><div><div className="category-selector" role="group" aria-label="Choose a project category">{projectTypes.map(type => <Button key={type} variant={category === type ? 'default' : 'outline'} aria-pressed={category === type} onClick={() => setCategory(type)}>{type}</Button>)}</div><WhatsAppLink message={`Hi Kunal SMK, I need help planning a project. Category: ${category}. Can we discuss my idea and the best starting point?`}>Help Me Plan My Project</WhatsAppLink></div></div>;
}
