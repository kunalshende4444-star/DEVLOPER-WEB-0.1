import { useEffect, useState } from 'react';
import { Link, useLocation } from '@tanstack/react-router';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import logoImage from '@/assets/smk-logo.png';
import { studio, services } from '@/lib/studio-config';
import { whatsappUrl } from '@/lib/whatsapp';
import { WhatsAppIcon, WhatsAppLink } from './whatsapp-link';
export const navigation = [{ title: 'Home', to: '/' }, { title: 'Services', to: '/services' }, { title: 'Portfolio', to: '/portfolio' }, { title: 'Process', to: '/process' }, { title: 'Pricing', to: '/pricing' }, { title: 'FAQ', to: '/faq' }, { title: 'Contact', to: '/contact' }] as const;
export function Brand() {
  return <Link to="/" className="brand" aria-label={`${studio.name} home`}><img className="monogram" src={logoImage} alt="" width={42} height={42}/><div className="brand-words">{studio.shortName}<span>DEVELOPMENT</span></div></Link>;
}
export function Header() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  useEffect(() => { setOpen(false); }, [location.pathname]);
  useEffect(() => { if (!open) return; const close = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); }; window.addEventListener('keydown', close); return () => window.removeEventListener('keydown', close); }, [open]);
  return <><a href="#main" className="skip-link">Skip to content</a><header className="site-header"><div className="shell header-inner"><Brand/><nav className="desktop-nav" aria-label="Main navigation">{navigation.map(item => <Link key={item.to} to={item.to} className="nav-link" activeOptions={{ exact: true }}>{item.title}</Link>)}</nav><WhatsAppLink className="header-cta" icon="whatsapp">Let's Talk</WhatsAppLink><Button variant="ghost" size="icon" className="mobile-toggle" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen(!open)}>{open ? <X/> : <Menu/>}</Button></div>{open && <nav id="mobile-menu" className="mobile-nav" aria-label="Mobile navigation">{navigation.map(item => <Link to={item.to} key={item.to} onClick={() => setOpen(false)} className="nav-link">{item.title}</Link>)}<a href={whatsappUrl()} target="_blank" rel="noopener noreferrer">Discuss Your Project ↗</a></nav>}</header></>;
}
export function Footer() {
  const [year, setYear] = useState('2026');
  useEffect(() => { setYear(String(new Date().getFullYear())); }, []);
  const path = useLocation().pathname;
  return <><footer className="site-footer"><div className="shell"><div className="footer-grid"><div className="footer-brand"><Brand/><p>Thoughtful development.<br/>Practical solutions. Built around you.</p></div><div><div className="footer-heading">EXPLORE</div><nav className="footer-links" aria-label="Footer navigation">{navigation.filter(i => i.to !== '/').map(item => <Link key={item.to} to={item.to}>{item.title}</Link>)}</nav></div><div><div className="footer-heading">DEVELOPMENT</div><div className="footer-links">{services.filter(s => s.enabled).slice(0,5).map(s => <a key={s.id} href={whatsappUrl(s.message)} target="_blank" rel="noopener noreferrer">{s.title}</a>)}</div></div><div><div className="footer-heading">START A CONVERSATION</div><div className="footer-links"><a href={whatsappUrl()} target="_blank" rel="noopener noreferrer">+91 {studio.whatsappNumber} ↗</a><Link to="/contact">Tell us about your idea</Link></div></div></div><div className="footer-bottom"><p>© {year} {studio.name}. All rights reserved.</p><div><Link to="/privacy">Privacy Policy</Link><Link to="/terms">Terms of Service</Link></div></div></div></footer><a className="floating-whatsapp" href={whatsappUrl(`Hi Kunal SMK, I am viewing the ${path === '/' ? 'home' : path.slice(1)} page on KUNAL SMK DEVELOPMENT and would like to discuss a project.`)} target="_blank" rel="noopener noreferrer" aria-label="Discuss your project on WhatsApp" title="Discuss your project on WhatsApp"><WhatsAppIcon/></a></>;
}
