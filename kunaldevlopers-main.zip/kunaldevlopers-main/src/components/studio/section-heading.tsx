import type { ReactNode } from 'react';
export function SectionHeading({ label, title, description, action }: { label: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="section-head"><div><div className="eyebrow">{label}</div><h2>{title}</h2></div>{action || (description && <p className="section-description">{description}</p>)}</div>;
}
export function PageIntro({ label, title, description }: { label: string; title: string; description: string }) {
  return <div className="shell page-intro"><div className="eyebrow">{label}</div><h1>{title}</h1><p>{description}</p></div>;
}
