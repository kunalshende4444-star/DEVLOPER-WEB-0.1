import { Plus } from 'lucide-react';
import { faqs } from '@/lib/studio-config';
export function FAQList({ preview = false }: { preview?: boolean }) { return <div className="faq-list">{(preview ? faqs.slice(0,4) : faqs).map(([question, answer]) => <details className="faq-item" key={question}><summary>{question}<Plus aria-hidden="true"/></summary><p>{answer}</p></details>)}</div>; }
