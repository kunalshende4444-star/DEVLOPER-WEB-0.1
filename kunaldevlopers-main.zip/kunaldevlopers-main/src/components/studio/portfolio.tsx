import { useState } from 'react';
import { Smartphone, LayoutDashboard, Code2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import websiteImage from '@/assets/concept-website.jpg';
import dashboardImage from '@/assets/concept-dashboard.jpg';
import storeImage from '@/assets/concept-store.jpg';
import { WhatsAppLink } from './whatsapp-link';
export const projects = [
  { title: 'Business Landing Page Concept', category: 'Websites', description: 'An editorial business presence with a clear story and focused inquiry path.', image: websiteImage },
  { title: 'Tournament Dashboard Concept', category: 'Admin Panels', description: 'A structured interface for managing events, teams and match information. All data shown is illustrative.', image: dashboardImage },
  { title: 'E-commerce Store Concept', category: 'E-commerce', description: 'A considered product catalog with simple browsing and a clean visual hierarchy.', image: storeImage },
  { title: 'Android App Interface Concept', category: 'Android Apps', description: 'An exploration of mobile navigation, user profiles and application screens.', icon: Smartphone },
  { title: 'Admin Panel Interface Concept', category: 'Admin Panels', description: 'An interface direction for searchable records, access controls and configuration.', icon: LayoutDashboard },
  { title: 'Developer Portfolio Concept', category: 'UI Concepts', description: 'A minimal approach to presenting development work and starting conversations.', icon: Code2 },
];
export function PortfolioGrid({ preview = false }: { preview?: boolean }) {
  const [filter, setFilter] = useState('All');
  const visible = (preview ? projects.slice(0,3) : projects).filter(p => filter === 'All' || filter === p.category);
  return <>{!preview && <div className="portfolio-filters" role="group" aria-label="Filter portfolio projects">{['All', 'Websites', 'Android Apps', 'Admin Panels', 'E-commerce', 'UI Concepts'].map(category => <Button key={category} variant={filter === category ? 'default' : 'outline'} aria-pressed={filter === category} onClick={() => setFilter(category)}>{category}</Button>)}</div>}<div className="project-grid">{visible.map(project => <article className="project-card" key={project.title}><div className="project-image">{project.image ? <img src={project.image} width={1200} height={800} loading="lazy" alt={`${project.title}: illustrative interface, not a completed client project`}/> : <div className="project-placeholder">{project.icon && <project.icon aria-hidden="true"/>}</div>}<span className="project-badge">UI DEMO · CONCEPT PROJECT</span></div><div className="project-category">{project.category.toUpperCase()}</div><h3>{project.title}</h3><p>{project.description}</p><WhatsAppLink message={`Hi Kunal SMK, I saw the ${project.title} UI concept and would like to discuss a similar project.`} variant="ghost" className="service-action">Ask About Similar Project</WhatsAppLink></article>)}</div>{!visible.length && <div className="empty-state">No projects in this category yet. Choose another category or discuss your idea with us.</div>}</>;
}
