import { services, studio } from '@/lib/studio-config';
import { whatsappUrl } from '@/lib/whatsapp';
import { WhatsAppLink } from './whatsapp-link';
import { InquiryForm } from './inquiry-form';
import { BriefAssistant } from './brief-assistant';
export function ContactContent() { return <><div className="contact-grid"><div className="contact-aside"><div className="eyebrow">One idea. One conversation.</div><h2>LET'S BUILD SOMETHING<br/>THAT WORKS FOR YOU.</h2><p>Have an idea, need a website, or want to improve an existing application? Tell us what you need and start a project discussion.</p><WhatsAppLink icon="whatsapp">Chat on WhatsApp</WhatsAppLink><div className="contact-number">+91 {studio.whatsappNumber}</div><p>Prefer to start with a service?</p><div className="contact-shortcuts">{services.filter(s => s.enabled).map(s => <a key={s.id} href={whatsappUrl(s.message)} target="_blank" rel="noopener noreferrer">{s.title} ↗</a>)}</div></div><InquiryForm/></div><BriefAssistant/></>; }
