import type { ReactNode } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { whatsappUrl, generalMessage } from '@/lib/whatsapp';
export function WhatsAppIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><path d="M20.5 11.6a8.4 8.4 0 0 1-12.4 7.5L3 20.5l1.4-4.9a8.4 8.4 0 1 1 16.1-4Z"/><path d="M8.2 7.5c-.7.4-.9 1.5-.4 2.8.8 2.2 2.7 4 4.9 4.8 1.4.5 2.4.1 2.8-.5l.3-1.2-2.2-1-1 1c-1.6-.5-3-1.8-3.5-3.4l.9-.9-1-2.1Z"/></svg>;
}
export function WhatsAppLink({ children, message = generalMessage, variant = 'default', className = '', icon = 'arrow' }: { children: ReactNode; message?: string; variant?: 'default' | 'outline' | 'ghost' | 'link'; className?: string; icon?: 'arrow' | 'whatsapp' }) {
  return <Button variant={variant} asChild className={`studio-button ${className}`}><a href={whatsappUrl(message)} target="_blank" rel="noopener noreferrer">{children}{icon === 'whatsapp' ? <WhatsAppIcon/> : <ArrowUpRight/>}</a></Button>;
}
