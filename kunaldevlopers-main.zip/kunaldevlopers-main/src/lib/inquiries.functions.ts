import { createServerFn } from '@tanstack/react-start';
import { inquirySchema } from './whatsapp';

// Public intake only: no reads, updates or deletes. Zod validates before any privileged access.
export const saveInquiry = createServerFn({ method: 'POST' })
  .inputValidator((input: unknown) => inquirySchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
    const { data: row, error } = await supabaseAdmin.from('project_inquiries').insert({
      name: data.name, project_type: data.projectType, description: data.description,
      features: data.features, budget: data.budget, desired_date: data.desiredDate, contact_method: data.contactMethod,
    }).select('id').single();
    if (error || !row) return { ok: false as const };
    return { ok: true as const, id: row.id };
  });