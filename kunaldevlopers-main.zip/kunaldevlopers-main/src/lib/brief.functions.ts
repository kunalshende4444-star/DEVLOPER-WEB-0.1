import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';

export const briefInputSchema = z.object({
  idea: z.string().trim().min(20, 'Please describe your project in at least 20 characters.').max(2000, 'Keep it under 2,000 characters.'),
});

const instructions = `You help prospective clients of KUNAL SMK DEVELOPMENT, an independent developer studio (websites, Android apps, admin panels, tournament platforms, e-commerce, Firebase/API integration, custom software, redesigns and bug fixing).
Write a concise project brief in plain text with these headings on their own lines: PROJECT SUMMARY, KEY FEATURES, SUGGESTED SCOPE (MVP vs later), QUESTIONS TO CLARIFY, RECOMMENDED NEXT STEPS.
Use short "- " bullet points. Never quote prices, timelines as promises, guarantees, or technologies as confirmed; say the final scope and quotation are agreed in discussion with Kunal SMK. Last next step: share this brief on WhatsApp. Under 350 words.`;

export const generateBrief = createServerFn({ method: 'POST' })
  .inputValidator((input: unknown) => briefInputSchema.parse(input))
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) return { ok: false as const, error: 'The brief assistant is not configured yet.' };
    const { createOpenAI } = await import('@ai-sdk/openai');
    const { streamText } = await import('ai');
    const provider = createOpenAI({
      baseURL: 'https://ai.gateway.lovable.dev/v1',
      apiKey,
      headers: { 'Lovable-API-Key': apiKey, 'X-Lovable-AIG-SDK': 'vercel-ai-sdk' },
    });
    let failure: unknown;
    try {
      const result = streamText({
        model: provider.responses('openai/gpt-6-astra'),
        system: instructions,
        messages: [{ role: 'user', content: data.idea }],
        maxRetries: 0,
        onError: ({ error }) => { failure = error; },
        providerOptions: { openai: { forceReasoning: true, reasoningEffort: 'low', store: false } },
      });
      const text = (await result.text).trim();
      if (!text) throw failure ?? new Error('empty');
      return { ok: true as const, brief: text };
    } catch (error) {
      const err = (failure ?? error) as { statusCode?: number };
      console.error('brief generation failed', failure ?? error);
      const message = err?.statusCode === 429 ? 'The assistant is busy right now. Please try again in a minute.'
        : err?.statusCode === 402 ? 'The brief assistant is temporarily unavailable. Please continue on WhatsApp.'
        : 'We could not generate a brief. Please try again or continue on WhatsApp.';
      return { ok: false as const, error: message };
    }
  });
