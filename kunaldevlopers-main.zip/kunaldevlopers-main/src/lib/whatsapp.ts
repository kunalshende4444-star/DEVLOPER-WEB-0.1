import { z } from 'zod';
import { projectTypes, studio } from './studio-config';

export const generalMessage = 'Hi Kunal SMK, I have a project idea and would like to discuss it with KUNAL SMK DEVELOPMENT.';
export const inquirySchema = z.object({
  name: z.string().trim().min(1, 'Please enter your name.').max(100, 'Keep your name under 100 characters.'),
  projectType: z.enum(projectTypes, { errorMap: () => ({ message: 'Please select a project type.' }) }),
  description: z.string().trim().min(1, 'Please describe your project.').max(1500, 'Keep the description under 1,500 characters.'),
  features: z.string().trim().max(1000, 'Keep the feature list under 1,000 characters.'),
  budget: z.string().trim().max(100),
  desiredDate: z.string().refine(value => !value || /^\d{4}-\d{2}-\d{2}$/.test(value), 'Please enter a valid date.'),
  contactMethod: z.literal('WhatsApp'),
});
export type Inquiry = z.infer<typeof inquirySchema>;
export function whatsappUrl(message: string = generalMessage) {
  const safeMessage = z.string().trim().min(1).max(5000).parse(message);
  const number = z.string().regex(/^\d{10,15}$/).parse(studio.countryCode + studio.whatsappNumber);
  return `https://wa.me/${number}?text=${encodeURIComponent(safeMessage)}`;
}
export function inquiryMessage(input: Inquiry) {
  const data = inquirySchema.parse(input);
  return [`Hi Kunal SMK, I would like to discuss a project.`, '', `Name: ${data.name}`, `Project type: ${data.projectType}`, `Description: ${data.description}`, data.features && `Required features: ${data.features}`, data.budget && `Approximate budget: ${data.budget}`, data.desiredDate && `Preferred completion date: ${data.desiredDate}`, `Preferred contact: ${data.contactMethod}`, '', 'Please help me understand the scope, process and quotation.'].filter(Boolean).join('\n');
}