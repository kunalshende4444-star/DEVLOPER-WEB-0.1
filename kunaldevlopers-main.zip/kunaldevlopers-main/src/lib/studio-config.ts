export const studio = {
  name: 'KUNAL SMK DEVELOPMENT',
  shortName: 'KUNAL SMK',
  countryCode: '91',
  whatsappNumber: '7745041104',
  // Only add confirmed professional capabilities here. This site's implementation is not a claim of business expertise.
  technologies: [] as { name: string; enabled: boolean }[],
};

export const projectTypes = ['Website', 'Android application', 'Admin dashboard', 'Tournament platform', 'E-commerce', 'API integration', 'Existing project repair', 'Other'] as const;

export const services = [
  { id: 'website', icon: 'website', title: 'Website Development', description: 'Modern, responsive websites that present your business professionally and help customers understand your services.', capabilities: ['Business & personal websites', 'Landing & product pages', 'Responsive page layouts', 'Contact & inquiry integration'], cta: 'Discuss Website Project', message: 'Hi Kunal SMK, I want to discuss a website development project. Please help me understand the process and quotation.', enabled: true },
  { id: 'android', icon: 'android', title: 'Android App Development', description: 'Custom Android application development for businesses, communities and digital products.', capabilities: ['App interfaces & navigation', 'Login & user profiles', 'API & Firebase integration', 'Testing & deployment guidance'], note: 'Feasibility depends on Android platform requirements and the agreed features.', cta: 'Discuss Android App', message: 'Hi Kunal SMK, I want to discuss an Android app development project and its requirements.', enabled: true },
  { id: 'admin', icon: 'admin', title: 'Admin Panel Development', description: 'Custom administration dashboards to manage users, content, products and application workflows.', capabilities: ['User & content management', 'Role-based access', 'Searchable data tables', 'Reports & configurable settings'], note: 'Authentication, permissions and database security are scoped to each project.', cta: 'Discuss Admin Panel', message: 'Hi Kunal SMK, I need a custom admin panel. Can we discuss the features, access permissions and quotation?', enabled: true },
  { id: 'tournament', icon: 'tournament', title: 'Tournament Management', description: 'Tournament websites and management systems for gaming communities and esports organizers.', capabilities: ['Event listings & registration', 'Team & player management', 'Match information & results', 'Admin management tools'], note: 'Real-time features require suitable backend infrastructure.', cta: 'Discuss Tournament Project', message: 'Hi Kunal SMK, I want to discuss a tournament management system for my community.', enabled: true },
  { id: 'store', icon: 'store', title: 'E-commerce & Digital Stores', description: 'Online storefronts that present products, organize categories and connect customers to your business.', capabilities: ['Product catalogs & categories', 'Product search & detail pages', 'Order inquiry workflows', 'Configured payment integrations'], note: 'Payments require a real provider to be configured and tested.', cta: 'Discuss Online Store', message: 'Hi Kunal SMK, I want to discuss an e-commerce website or digital store and its requirements.', enabled: true },
  { id: 'integration', icon: 'integration', title: 'Firebase & API Integration', description: 'Connect websites and applications to suitable backend services, authentication systems and APIs.', capabilities: ['Authentication integration', 'Firestore & Realtime Database', 'API connectivity & sync', 'Configuration & error handling'], note: 'Credentials and database security rules must be configured for each project.', cta: 'Discuss Integration', message: 'Hi Kunal SMK, I need help with Firebase or API integration for my project.', enabled: true },
  { id: 'custom', icon: 'custom', title: 'Custom Software & Automation', description: 'Practical digital tools and workflows built around a specific business requirement.', capabilities: ['Internal tools & dashboards', 'Data management interfaces', 'Workflow automation', 'API-based utilities'], cta: 'Discuss Custom Software', message: 'Hi Kunal SMK, I have an idea for custom software or automation. Can we discuss its feasibility?', enabled: true },
  { id: 'repair', icon: 'repair', title: 'Redesign & Bug Fixing', description: 'Improve an existing project with interface updates, responsive fixes and feature enhancements.', capabilities: ['Visual redesign & mobile fixes', 'Code troubleshooting', 'Performance improvements', 'Modifications & deployment help'], note: 'Changes depend on access to source code, permissions and project compatibility.', cta: 'Fix or Improve My Project', message: 'Hi Kunal SMK, I need maintenance, bug fixing or modifications to an existing project. Can we discuss it?', enabled: true },
];

export const pricing = [
  { name: 'Starter Project', description: 'A focused landing page or small website to put your idea online.', price: 'Custom Quote', features: ['Focused project scope', 'Responsive page design', 'Contact & inquiry integration', 'Testing & handover'], cta: 'Get a Website Quote', message: 'Hi Kunal SMK, I would like a quotation for a landing page or small website.' },
  { name: 'Business Project', description: 'Multi-page websites and more advanced business requirements.', price: 'Custom Quote', features: ['Requirement-based page structure', 'Custom business features', 'Integration planning', 'Progress updates & testing'], cta: 'Discuss My Requirements', message: 'Hi Kunal SMK, I would like to discuss my business project requirements and quotation.' },
  { name: 'Custom Development', description: 'Apps, admin panels, integrations and more complex digital systems.', price: 'Based on Scope', features: ['Technical feasibility discussion', 'Custom application workflows', 'Backend & API scoping', 'Agreed setup documentation'], cta: 'Request a Consultation', message: 'Hi Kunal SMK, I would like a consultation and project quotation for a custom development project.' },
];

export const processSteps = [
  { title: 'Discovery', description: 'Tell us about your idea, the features you need, your budget range and your preferred timeline.' },
  { title: 'Scope & Quotation', description: 'We review the requirements and discuss technical needs, deliverables, a quotation and a realistic timeline.' },
  { title: 'Design & Development', description: 'Your project takes shape around the agreed scope, with progress communication and opportunities for feedback.' },
  { title: 'Testing & Handover', description: 'We test and review the agreed deliverables, then hand them over with applicable setup instructions.' },
];

export const faqs = [
  ['What types of projects can I discuss?', 'Websites, Android apps, admin panels, tournament platforms, online stores, integrations and existing project improvements. We review feasibility before agreeing to a scope.'],
  ['How do I request a quotation?', 'Describe your idea on WhatsApp or complete the project inquiry form. Include the features you need and any budget or timeline preferences so we can discuss a suitable scope.'],
  ['Can you work on an existing website or application?', 'We can discuss redesigns, troubleshooting and enhancements. Work depends on access to the source code, required permissions and technical compatibility.'],
  ['Can I request a custom admin panel?', 'Yes, we can discuss a panel tailored to your workflow. User roles, authentication, permissions and database security are defined in the project scope.'],
  ['How are project timelines decided?', 'Timelines are discussed after reviewing scope, complexity, revisions and dependencies. A preferred date is a request, not a confirmed delivery commitment.'],
  ['Do you provide source code?', 'Source code, ownership and handover arrangements are discussed and included in the agreed deliverables before development starts. Third-party licenses may apply.'],
  ['Can you integrate Firebase or external APIs?', 'Integration can be discussed when the service supports your requirements. Account access, credentials, security rules, provider limits and any recurring costs must be scoped.'],
  ['How do revisions work?', 'The number and type of revisions are agreed before work starts. Changes outside the original scope may need an updated quotation and timeline.'],
  ['Do you provide post-delivery support?', 'Support, maintenance and bug-fix arrangements are based on the agreed scope. Duration and any additional fees are discussed rather than assumed.'],
  ['How can I contact you?', 'Start a WhatsApp conversation at +91 7745041104. You can edit any prefilled message and must press Send in WhatsApp to deliver it.'],
];