import { describe, expect, it } from 'vitest';
import { inquirySchema, inquiryMessage, whatsappUrl } from '@/lib/whatsapp';
import { services, pricing } from '@/lib/studio-config';
const valid = { name: 'Visitor', projectType: 'Website' as const, description: 'A business site', features: '', budget: '', desiredDate: '', contactMethod: 'WhatsApp' as const };
describe('WhatsApp project inquiries', () => {
  it('uses the exact India contact number', () => { expect(new URL(whatsappUrl()).pathname).toBe('/917745041104'); });
  it('encodes messages without losing punctuation or line breaks', () => { const message = 'Website & apps?\nBudget: ₹20,000 / scope'; expect(new URL(whatsappUrl(message)).searchParams.get('text')).toBe(message); });
  it('requires name', () => { expect(inquirySchema.safeParse({ ...valid, name: '   ' }).success).toBe(false); });
  it('requires project type', () => { expect(inquirySchema.safeParse({ ...valid, projectType: '' }).success).toBe(false); });
  it('requires project description', () => { expect(inquirySchema.safeParse({ ...valid, description: ' ' }).success).toBe(false); });
  it('trims submitted whitespace', () => { expect(inquirySchema.parse({ ...valid, name: ' Visitor ' }).name).toBe('Visitor'); });
  it('rejects excessively long descriptions', () => { expect(inquirySchema.safeParse({ ...valid, description: 'x'.repeat(1501) }).success).toBe(false); });
  it('includes entered details in the WhatsApp message', () => { const message = inquiryMessage({ ...valid, features: 'Product catalog', budget: 'To discuss', desiredDate: '2026-12-01' }); expect(message).toContain('Name: Visitor'); expect(message).toContain('Project type: Website'); expect(message).toContain('Required features: Product catalog'); expect(message).toContain('2026-12-01'); });
  it('uses the configured contact for every service', () => { for (const service of services) expect(new URL(whatsappUrl(service.message)).pathname).toBe('/917745041104'); });
  it('does not invent monetary prices', () => { expect(pricing.map(p => p.price)).toEqual(['Custom Quote', 'Custom Quote', 'Based on Scope']); });
});
