# KUNAL SMK DEVELOPMENT

A dark developer-studio website built with React, TypeScript, TanStack Start and Tailwind CSS v4.

## Local preview

Use Bun and a current supported Node.js installation. Run `bun install`, then `bun run dev` and open the address shown in your terminal. `bun run test` runs the tests. `bun run build` prepares deployment; `bun run preview` previews the output locally.

## Customization checklist

- **Logo:** replace `src/assets/smk-logo.png` (header/footer), `src/assets/smk-hero.jpg` (hero) and `public/favicon.png`. Full business name and short name live in `src/lib/studio-config.ts`.
- **Colors:** edit the OKLCH semantic tokens in `src/styles.css`. The primary accent, surface and text tokens drive all sections and controls.
- **Portfolio:** update `projects` in `src/components/studio/portfolio.tsx`, with real images and accurate descriptions. Remove concept labels only for confirmed completed work. Add a View Demo link only when a real, tested URL exists; never present a mock URL as live. Supplied concepts use generated illustration images, not functional app demos.
- **Services and pricing:** edit `services` and `pricing` in `src/lib/studio-config.ts`. Set a service's `enabled` to false to hide it. The current quotes are not fixed monetary prices.
- **Technologies:** add only confirmed professional capabilities to `studio.technologies`, with `enabled: true`. The section is hidden until configured, rather than claiming expertise based on this website's implementation.
- **WhatsApp:** edit `countryCode` and `whatsappNumber` in `studio-config.ts`; all links use the shared generator. No WhatsApp API key or account integration is needed. Messages are editable and visitors press Send themselves.
- **Publish:** use Publish in Lovable, review the deployment, and add a domain through project settings if desired. Set canonical URLs after the final domain is selected. Every page already has its own title and social metadata.

## Inquiry behavior and Cloud

The form validates both in the browser and in a server function. It saves a copy in `project_inquiries` through Lovable Cloud and then opens a prefilled WhatsApp conversation. Visitors must press Send in WhatsApp. A saved copy is not proof that a WhatsApp message was sent. The owner can open Cloud → Database → project_inquiries. No visitor accounts or public inquiry reads are exposed. No form values are stored in local storage.

Inquiry copies remain until the owner removes them; no automatic retention schedule is configured. The privacy page describes this. No automatic owner or visitor emails are configured. Sending owner emails requires a paid plan, a verified owned sending domain and an owner address; after verification, request owner notifications to wire and test delivery. A domain purchased through Lovable verifies automatically; external domains require DNS verification. No standard backend rate limiting is available; add appropriate abuse protection before high-volume exposure if needed.

## Environment configuration

WhatsApp links and all public page content need no secrets. Lovable configures the Cloud connection automatically for hosted previews and publishing. For a separate local environment the Cloud client expects `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` (publishable only); the inquiry server uses `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` inside server-only handlers. Do not commit private credentials, prefix private keys with `VITE_`, or expose them in client code. Obtain valid credentials through your deployment provider rather than inventing them. Without a configured Cloud connection, the form displays an error and direct WhatsApp links still work.

Only inquiry-copy storage uses the implemented backend. Portfolio previews, pricing cards and offered services do not imply operational payment processing, Android builds, Firebase services, real-time tournament systems or customer admin panels. Those require separate real project infrastructure, access, security configuration and testing.
