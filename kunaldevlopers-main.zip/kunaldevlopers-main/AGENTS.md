<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project architecture
- Keep business offerings, contact details, pricing and confirmed technology visibility in a central configuration so the site remains maintainable.
- Use shared studio sections across independently shareable public routes, with route-specific metadata and accessible navigation.
- Generate all WhatsApp URLs with one validated helper and validate inquiry fields with a shared Zod schema on browser and server.
- Store submitted inquiry copies through a public write-only server function; the database grants only privileged access so visitor data is never publicly readable.
- Use global semantic design tokens and the existing Button for controls; keep generated project imagery bundled and label concepts honestly.
- Prebundle React, its renderer and JSX runtimes together in Vite so dependency discovery does not mix hook-dispatcher generations in an open preview.
- AI project briefs run in a public server function on the AI gateway with server-held keys and no storage of the idea text, so visitor input stays private and costs stay controlled.
